package com.example.mainlogin;


import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


public class BookIssue3 {
    private final StringProperty id;
    private final StringProperty book;
    private final StringProperty price;
    //private final StringProperty unitprice;


    public BookIssue3() {
        id = new SimpleStringProperty(this, "id");
        book= new SimpleStringProperty(this, "book");
        price = new SimpleStringProperty(this, "price");
}

    public String getId() {
        return id.get();
    }

    public StringProperty idProperty() {
        return id;
    }

    public void setId(String id) {
        this.id.set(id);
    }

    public String getBook() {
        return book.get();
    }

    public StringProperty bookProperty() {
        return book;
    }

    public void setBook(String book) {
        this.book.set(book);
    }

    public String getPrice() {
        return price.get();
    }

    public StringProperty priceProperty() {
        return price;
    }

    public void setPrice(String price) {
        this.price.set(price);
    }
}