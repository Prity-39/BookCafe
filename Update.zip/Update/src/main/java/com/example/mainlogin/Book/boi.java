package com.example.mainlogin.Book;

public class boi implements Book{
    static int id;
    static String name;
    static String author;
    static String genre;
    static String publisher;
    static String price;
    //String type;
    static String availability;

    public boi(int id, String name, String author, String genre, String publisher, String price, String availability){
        this.id=id;
        this.name = name;
        this.author = author;
        this.genre=genre;
        this.publisher=publisher;
        this.price=price;
        //this.type=type;
        this.availability=availability;

    }

    public static int getId() {
        return id;
    }

    public static String getName() {
        return name;
    }

    public static String getAuthor() {
        return author;
    }

    public static String getGenre() {
        return genre;
    }

    public static String getPublisher() {
        return publisher;
    }

    public static String getPrice() {
        return price;
    }

    /*public String getType() {
        return type;
    }*/

    public static String getAvailability() {
        return availability;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public void setPublisher(String publishers) {
        this.publisher = publisher;
    }

    public void setPrice(String price) {
        this.price = price;
    }

   // public void setType(String type) {
       // this.type = type;
    //}

    public void setAvailability(String n_available) {
        this.availability = availability;
    }
}
