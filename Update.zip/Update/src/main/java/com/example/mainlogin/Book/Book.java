package com.example.mainlogin.Book;

public interface Book {
    default void processing(String url) {

    }

}


