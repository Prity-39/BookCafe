package com.example.mainlogin;


public class MemberSearchModel {
    /*
    Integer productID;
    String brand, modelNumber;
    Integer modelYear;
    String productName, description;

     */
    Integer memberId;
    String name, phone, address, date;
    //Integer modelYear;
    //String productName, description;


    public MemberSearchModel(Integer memberId, String name, String phone, String address, String date){
        this.memberId = memberId;
        this.name = name;
        this.phone = phone;
        //this.modelYear = modelYear;
        this.address = address;
        this.date = date;
        //this.due = due;
        //this.availability = availability;
    }

    public Integer getMemberId() {
        return memberId;
    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    public String getDate() {
        return date;
    }

    //public String getDue() {
      //  return due;
    //}

    public void setMemberId(Integer memberId) {
        this.memberId = memberId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setDate(String date) {
        this.date = date;
    }

    //public void setDue(String due) {
      //  this.due = due;
    //}

}
