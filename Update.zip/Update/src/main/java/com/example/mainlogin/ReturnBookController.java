package com.example.mainlogin;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ReturnBookController implements Initializable {
    public TextField rtnbknmtf;
    public TextField rtnmemnmtf;
    public TextField rtnqtytf;
    public Button rtnbtnfx;
    public TextField rtnmemidtf;
    public Button lendfx;
    public Label rtntrlabel;

    Connection con;
    PreparedStatement pst;
    int myIndex;
    int id;

    public void Connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/planet", "root", "the1236@$gifted");
        } catch (ClassNotFoundException ex) {

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    void clear2() {
        rtnmemnmtf.setText("");
        rtnmemidtf.setText("");
        rtnbknmtf.setText("");
        rtnqtytf.setText("");
        //cklabel.setText("");
        //ck2tf.setText("");
    }


        public void rtnbtnaction(ActionEvent event) throws Exception{

            String membername = rtnmemnmtf.getText();
            String memberid = rtnmemidtf.getText();
            String bookname = rtnbknmtf.getText();
            String quantity = rtnqtytf.getText();

            String s ="";
            if(membername != s && memberid != s && bookname != s && quantity !=s){

                    rtntrlabel.setText("Book is returned!");}






            else {
                rtntrlabel.setText("Please enter information");
            }

            }






    public void backlend(ActionEvent event) throws Exception{
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("IssueNew.fxml"));
        Stage window = (Stage) lendfx.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Connect();
    }
}
