package com.example.mainlogin;



import com.example.mainlogin.database.DatabaseConnection;
import com.jfoenix.controls.JFXButton;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class IssueBookController implements Initializable {


    public Pane pn_bb;
    public Pane pn_lb;
    public Pane pn_rb;

    public JFXButton bb;
    public JFXButton lb;
    public JFXButton rb;
    public Button btnissue;
    public TextField midtf;
    public TextField mntf;
    public TextField lbtf;
    public Button lissue;
    //public TableView ltable;


    @FXML
    private TextField cntf;

    @FXML
    private TextField bntf;
    @FXML
    private TextField uptf;


    @FXML
    private TextField qtytf;

    //@FXML
    //private TextField tottf;

    //@FXML
    //private TextField avltf;

    public TextField totlabel;

    //@FXML
    //private TextField prtf;


    @FXML
    private TableView<Iss> table;

    @FXML
    private TableColumn<Iss, String> idtc;

    @FXML
    private TableColumn<Iss, String> cntc;

    @FXML
    private TableColumn<Iss, String> bntc;

    @FXML
    private TableColumn<Iss, String> uptc;

    @FXML
    private TableColumn<Iss, String> qtytc;

    @FXML
    private TableColumn<Iss, String> tottc;

    //@FXML
    //private TableColumn<BookIssue, String> prtc;

    @FXML
    private Button btnAdd;   // save button
    @FXML
    private Button totbtn;

    @FXML
    private Button addbook;

    @FXML
    private TableView<BookIssue3> booktable;

    @FXML
    private TableColumn<BookIssue3, String> idbooktc;

    @FXML
    private TableColumn<BookIssue3, String> bookbooktc;
    @FXML
    private TableColumn<BookIssue3, String> pricebooktc;


    @FXML
    private Button btnReturn6;

    Connection con;
    PreparedStatement pst;
    int myIndex;
    int id;

    public void Connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/planet", "root", "the1236@$gifted");
        } catch (ClassNotFoundException ex) {

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }


    //click << button of IssueBook page to enter Dashboard page
    public void handleBtn4() throws Exception {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Dashboard.fxml"));
        Stage window = (Stage) btnReturn6.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));

    }

    void clear() {
        cntf.setText("");
        bntf.setText("");
        uptf.setText("");
        qtytf.setText("");
        totlabel.setText("");
        //totalshow.setText("");
    }


    public void handleButton(ActionEvent event) {
        if (event.getSource() == bb) {
            pn_bb.toFront();
        } else if (event.getSource() == lb) {
            pn_lb.toFront();
        } else if (event.getSource() == rb) {
            pn_rb.toFront();
        }
    }

    public void tablesell() {
        Connect();
        ObservableList<Iss> students = FXCollections.observableArrayList();
        try {
            pst = con.prepareStatement("select id,customername,bookname,unitprice,quantity,total from sellbook3");
            ResultSet rs = pst.executeQuery();
            {
                while (rs.next()) {
                    Iss st = new Iss();

                    st.setId(rs.getString("id"));
                    st.setCustomername(rs.getString("customername"));
                    st.setBookname(rs.getString("bookname"));
                    st.setUnitprice(rs.getString("unitprice"));
                    st.setQuantity(rs.getString("quantity"));
                    st.setTotal(rs.getString("total"));
                    students.add(st);


                    //students.add(new Employee(rs.getString("id"), rs.getString("name"), rs.getString("mobile"), rs.getString("address"), rs.getString("designation")));
                }
            }
            table.setItems(students);
            idtc.setCellValueFactory(f -> f.getValue().idProperty());
            cntc.setCellValueFactory(f -> f.getValue().customernameProperty());
            bntc.setCellValueFactory(f -> f.getValue().booknameProperty());
            uptc.setCellValueFactory(f -> f.getValue().unitpriceProperty());
            qtytc.setCellValueFactory(f -> f.getValue().quantityProperty());
            tottc.setCellValueFactory(f -> f.getValue().totalProperty());


        } catch (SQLException ex) {
            Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
        }

        table.setRowFactory(tv -> {
            TableRow<Iss> myRow = new TableRow<>();
            myRow.setOnMouseClicked(event ->
            {
                if (event.getClickCount() == 1 && (!myRow.isEmpty())) {
                    myIndex = table.getSelectionModel().getSelectedIndex();
                    id = Integer.parseInt(String.valueOf(table.getItems().get(myIndex).getId()));
                    cntf.setText(table.getItems().get(myIndex).getCustomername());
                    bntf.setText(table.getItems().get(myIndex).getBookname());
                    uptf.setText(table.getItems().get(myIndex).getUnitprice());
                    qtytf.setText(table.getItems().get(myIndex).getQuantity());
                    totlabel.setText(table.getItems().get(myIndex).getTotal());


                }
            });
            return myRow;
        });


    }


    int flag = 0;

    //@FXML
    void totaction(ActionEvent event) {

        String unitprice = uptf.getText();
        String quantity = qtytf.getText();
        //String qua = qtytf.getText();
        String s = "";
        if (unitprice != s && quantity != s) {
            int inunitprice = Integer.parseInt(unitprice);
            int inquantity = Integer.parseInt(quantity);
            int total = inunitprice * inquantity;
            String t = Integer.toString(total);
            totlabel.setText(t);
            flag = 1;
        }
    }


    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Connect();
        //  tablebook();
        tablesell();
    }


    public void bookaction(ActionEvent event) {
    }

    public void issue(ActionEvent event) throws Exception {
        String customername = cntf.getText();
        String bookname = bntf.getText();
        String unitprice = uptf.getText();
        String quantity = qtytf.getText();
        String total = totlabel.getText();
        if (flag == 1) {

            String s = "";
            if (customername != s && bookname != s && unitprice != s && quantity != s && total != s) {

                try {
                    pst = con.prepareStatement("insert into sellbook3(customername,bookname,unitprice,quantity,total)values(?,?,?,?,?)");
                    pst.setString(1, customername);
                    pst.setString(2, bookname);
                    pst.setString(3, unitprice);
                    pst.setString(4, quantity);
                    pst.setString(5, total);


                    pst.executeUpdate();

                    tablesell();
                    clear();
                    flag = 0;
                } catch (SQLException ex) {
                    Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
}
/*
    int flagl = 1;//***************
    public void lbissue(ActionEvent event) {
        String memberid = midtf.getText();
        String membername = mntf.getText();
        String lendbookname = lbtf.getText();
        //String quantity = qtytf.getText();
        //String total = totlabel.getText();
        /*if(flagl == 1){

            String  s = "";
            if(memberid != s && membername != s && lendbookname != s ){

                try {
                    pst = con.prepareStatement("insert into booklend(memberid,membername,bookname)values(?,?,?)");
                    pst.setString(1,memberid);
                    pst.setString(2, membername);
                    pst.setString(3, lendbookname);
                    //pst.setString(4, quantity);
                   // pst.setString(5, total);


                    pst.executeUpdate();

                    //tablesell();
                    //clear();
                    //flag = 0;
                } catch (SQLException ex) {
                    Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
}*/

//@FXML
    /*void Add(ActionEvent event) {
        //textfield er variables

        String  customername = cntf.getText();
        //String ph_nm = bntf.getText();
        String bookname = bntf.getText();
        String quantity =qtytf.getText();
        String total =tottf.getText();
        //String availability =avltf.getText();
        try
        {
            pst = con.prepareStatement("insert into sellbook2(customername,bookname,quantity,total)values(?,?,?,?)");
            pst.setString(1, customername);
            //pst.setString(2, ph_nm);
            pst.setString(2, bookname);
            pst.setString(3, quantity);
            pst.setString(4, total);
            //pst.setString(6, pr);
            pst.executeUpdate();

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Issue Book");

            alert.setHeaderText("Book is Issuing...");
            alert.setContentText("Book Issued!");

            alert.showAndWait();

            /*table();

            cntf.setText("");
            //pntf.setText("");
            bntf.setText("");
            qtytf.setText("");
            tottf.setText("");*/
//prtf.setText("");
//cntf.requestFocus();
//}
        /*catch (SQLException ex)
        {
            Logger.getLogger(IssueBookController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }*/

    /*public void Connect()
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/planet","root","the1236@$gifted");
        } catch (ClassNotFoundException ex) {

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }*/

 /*void Add(ActionEvent event){
        String customername = cntf.getText();
        String bookname = bntf.getText();
        String unitprice = uptf.getText();
        String quantity = qtytf.getText();
        String total = totlabel.getText();

        if(flag == 1){
            String  s = "";
            if(customername != s && bookname != s && unitprice != s && quantity != s && total != s){

                try {
                    pst = con.prepareStatement("insert into sellbook3(customername,bookname,unitprice,quantity,total)values(?,?,?,?,?)");
                    pst.setString(1, customername);
                    pst.setString(2, bookname);
                    pst.setString(3, unitprice);
                    pst.setString(4, quantity);
                    pst.setString(5, total);


                    pst.executeUpdate();

                    //table();

                    clear();
                    flag = 0;
                } catch (SQLException ex) {
                    Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
                }




            }
        }
    }*/

/*


    public void tablebook()
    {
        Connect();
        ObservableList<BookIssue3> students = FXCollections.observableArrayList();
        try
        {
            pst = con.prepareStatement("select id,book,price from menubook");
            ResultSet rs = pst.executeQuery();
            {
                while (rs.next())
                {
                    BookIssue3 st = new BookIssue3();

                    st.setId(rs.getString("id"));
                    st.setBook(rs.getString("book"));
                    st.setPrice(rs.getString("price"));
                    //st.setAddress(rs.getString("address"));
                    //st.setDesignation(rs.getString("designation"));
                    students.add(st);



                    //students.add(new Employee(rs.getString("id"), rs.getString("name"), rs.getString("mobile"), rs.getString("address"), rs.getString("designation")));
                }
            }
            booktable.setItems(students);
            idbooktc.setCellValueFactory(f -> f.getValue().idProperty());
            bookbooktc.setCellValueFactory(f -> f.getValue().bookProperty());
            pricebooktc.setCellValueFactory(f -> f.getValue().priceProperty());
            //teaddress.setCellValueFactory(f -> f.getValue().addressProperty());
            //tedesignation.setCellValueFactory(f -> f.getValue().designationProperty());






        }

        catch (SQLException ex)
        {
            Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
        }

        booktable.setRowFactory( tv -> {
            TableRow<BookIssue3> myRow = new TableRow<>();
            myRow.setOnMouseClicked (event ->
            {
                if (event.getClickCount() == 1 && (!myRow.isEmpty()))
                {
                    myIndex =  booktable.getSelectionModel().getSelectedIndex();
                    id = Integer.parseInt(String.valueOf(booktable.getItems().get(myIndex).getId()));
                    bntf.setText(booktable.getItems().get(myIndex).getBook());
                    uptf.setText(booktable.getItems().get(myIndex).getPrice());
                    /*ephone.setText(table.getItems().get(myIndex).getMobile());
                    eaddress.setText(table.getItems().get(myIndex).getAddress());
                    edesignation.setText(table.getItems().get(myIndex).getDesignation());
                    //ecombobox.setAccessibleText(table.getItems().get(myIndex).getName());
                    eanswer.setText(table.getItems().get(myIndex).getAnswer());
                    epassword.setText(table.getItems().get(myIndex).getPassword());*/




                /*}
            });
            return myRow;
        });


    }
*/
/* public void table()
    {
        Connect();
        ObservableList<BookIssue2> students = FXCollections.observableArrayList();
        try
        {
            pst = con.prepareStatement("select id,customername,bookname,unitprice,quantity,total from sellbook3");
            ResultSet rs = pst.executeQuery();
            {
                while (rs.next())
                {
                    BookIssue2 st = new BookIssue2();

                    st.setId(rs.getString("id"));
                    st.setCustomername(rs.getString("customername"));
                    st.setBookname(rs.getString("bookname"));
                    st.setUnitprice(rs.getString("unitprice"));
                    st.setQuantity(rs.getString("quantity"));
                    st.setTotal(rs.getString("total"));
                    students.add(st);



                    //students.add(new Employee(rs.getString("id"), rs.getString("name"), rs.getString("mobile"), rs.getString("address"), rs.getString("designation")));
                }
            }
            table.setItems(students);
            idtc.setCellValueFactory(f -> f.getValue().idProperty());
            cntc.setCellValueFactory(f -> f.getValue().customernameProperty());
            bntc.setCellValueFactory(f -> f.getValue().booknameProperty());
            uptc.setCellValueFactory(f -> f.getValue().unitpriceProperty());
            qtytc.setCellValueFactory(f -> f.getValue().quantityProperty());
            tottc.setCellValueFactory(f -> f.getValue().totalProperty());






        }

        catch (SQLException ex)
        {
            Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
        }

        table.setRowFactory( tv -> {
            TableRow<BookIssue2> myRow = new TableRow<>();
            myRow.setOnMouseClicked (event ->
            {
                if (event.getClickCount() == 1 && (!myRow.isEmpty()))
                {
                    myIndex =  table.getSelectionModel().getSelectedIndex();
                    id = Integer.parseInt(String.valueOf(table.getItems().get(myIndex).getId()));
                    cntf.setText(table.getItems().get(myIndex).getCustomername());
                    bntf.setText(table.getItems().get(myIndex).getBookname());
                    uptf.setText(table.getItems().get(myIndex).getUnitprice());
                    qtytf.setText(table.getItems().get(myIndex).getQuantity());
                    totlabel.setText(table.getItems().get(myIndex).getTotal());
                    //ecombobox.setAccessibleText(table.getItems().get(myIndex).getName());
                    //eanswer.setText(table.getItems().get(myIndex).getAnswer());
                    //epassword.setText(table.getItems().get(myIndex).getPassword());




                }
            });
            return myRow;
        });





    }*/

//public void bookaction(ActionEvent event) throws Exception {
       /* String book = bntf.getText();
        String price = uptf.getText();

        try {
            pst = con.prepareStatement("insert into menubook(book,price)values(?,?)");
            pst.setString(1, book);
            pst.setString(2, price);

            pst.executeUpdate();

            tablebook();

            clear();
        } catch (SQLException ex) {
            Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
        }*/
//}

