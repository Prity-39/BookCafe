package com.example.mainlogin;

import com.example.mainlogin.database.Employee;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class RegistrationController implements Initializable {

    @FXML
    public TextField ename;

    @FXML
    public TextField eusername;
    @FXML
    public TextField ephone;
    @FXML
    public TextField eaddress;
    @FXML
    public TextField edesignation;
    @FXML
    public PasswordField epassword;
    
    @FXML
    public ComboBox ecombobox;
    String question ;
    @FXML
    public TextField eanswer;
    @FXML
    private TableView<Employee> table;
    @FXML
    private TableColumn<Employee, String> teid;
    @FXML
    private TableColumn<Employee, String> tename;

    @FXML
    private TableColumn<Employee, String> tephone;

    @FXML
    private TableColumn<Employee, String> teaddress;
    @FXML
    private TableColumn<Employee, String> tedesignation;



    @FXML
    public Button eupdate;
    @FXML
    public Button edelete;
    @FXML
    public Button esave;

    @FXML
    private Button btnReturn8;



    //click << button of Registration page to enter Login page
    public void handleBtn15() throws Exception{

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Login.fxml"));
        Stage window = (Stage) btnReturn8.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));

    }

    Connection con;
    PreparedStatement pst;
    int myIndex;
    int id;

    public void table()
    {
        Connect();
        ObservableList<Employee> students = FXCollections.observableArrayList();
        try
        {
            pst = con.prepareStatement("select id,name,mobile,address,designation from registation");
            ResultSet rs = pst.executeQuery();
            {
                while (rs.next())
                {
                    Employee st = new Employee();

                    st.setId(rs.getString("id"));
                    st.setName(rs.getString("name"));
                    st.setMobile(rs.getString("mobile"));
                    st.setAddress(rs.getString("address"));
                    st.setDesignation(rs.getString("designation"));
                    students.add(st);



                    //students.add(new Employee(rs.getString("id"), rs.getString("name"), rs.getString("mobile"), rs.getString("address"), rs.getString("designation")));
                }
            }
            table.setItems(students);
            teid.setCellValueFactory(f -> f.getValue().idProperty());
            tename.setCellValueFactory(f -> f.getValue().nameProperty());
            tephone.setCellValueFactory(f -> f.getValue().mobileProperty());
            teaddress.setCellValueFactory(f -> f.getValue().addressProperty());
            tedesignation.setCellValueFactory(f -> f.getValue().designationProperty());






        }

        catch (SQLException ex)
        {
            Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
        }

        table.setRowFactory( tv -> {
            TableRow<Employee> myRow = new TableRow<>();
            myRow.setOnMouseClicked (event ->
            {
                if (event.getClickCount() == 1 && (!myRow.isEmpty()))
                {
                    myIndex =  table.getSelectionModel().getSelectedIndex();
                    id = Integer.parseInt(String.valueOf(table.getItems().get(myIndex).getId()));
                    ename.setText(table.getItems().get(myIndex).getName());
                    eusername.setText(table.getItems().get(myIndex).getUsername());
                    ephone.setText(table.getItems().get(myIndex).getMobile());
                    eaddress.setText(table.getItems().get(myIndex).getAddress());
                    edesignation.setText(table.getItems().get(myIndex).getDesignation());
                    //ecombobox.setAccessibleText(table.getItems().get(myIndex).getName());
                    eanswer.setText(table.getItems().get(myIndex).getAnswer());
                    epassword.setText(table.getItems().get(myIndex).getPassword());




                }
            });
            return myRow;
        });


    }
    public void save(ActionEvent event) {
        String name = ename.getText();
        String username = eusername.getText();
        String mobile = ephone.getText();
        String address = eaddress.getText();
        String designation=edesignation.getText();
        //String question=ecombobox.getAccessibleText();
        String answer=eanswer.getText();
        String password=epassword.getText();
        try
        {
            pst = con.prepareStatement("insert into registation(name,username,mobile,address,designation,question,answer,password)values(?,?,?,?,?,?,?,?)");
            pst.setString(1, name);
            pst.setString(2, username);
            pst.setString(3, mobile);
            pst.setString(4, address);
            pst.setString(5, designation);
            pst.setString(6, question);
            pst.setString(7, answer);
            pst.setString(8, password);
            pst.executeUpdate();

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Employee Registration");

            alert.setHeaderText("Employee Registration");
            alert.setContentText("Employee Registared!");

            alert.showAndWait();

            table();

            ename.setText("");
            eusername.setText("");
            ephone.setText("");
            eaddress.setText("");
            edesignation.setText("");
            //ecombobox.setAccessibleText("");
            eanswer.setText("");
            epassword.setText("");
            ename.requestFocus();
        }
        catch (SQLException ex)
        {
            Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }



    public void delete(ActionEvent event) {
        myIndex = table.getSelectionModel().getSelectedIndex();
        id = Integer.parseInt(String.valueOf(table.getItems().get(myIndex).getId()));


        try
        {
            pst = con.prepareStatement("delete from registation where id = ? ");
            pst.setInt(1, id);
            pst.executeUpdate();

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Employee Record Deletion");

            alert.setHeaderText("Employee Record Delete...");
            alert.setContentText("Deletedd!");

            alert.showAndWait();
            table();
        }
        catch (SQLException ex)
        {
            Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }




    public void update(ActionEvent event) {

        myIndex = table.getSelectionModel().getSelectedIndex();
        id = Integer.parseInt(String.valueOf(table.getItems().get(myIndex).getId()));

        String name = ename.getText();
        String username = eusername.getText();
        String mobile = ephone.getText();
        String  address = eaddress.getText();
        String  designation=edesignation.getText();
        //String question = ecombobox.getAccessibleText();
        String  answer = eanswer.getText();
        String password=epassword.getText();
        try
        {
            pst = con.prepareStatement("update registation set name = ?,username = ?,mobile = ? ,address = ?,designation = ?,question = ?,answer = ?,password = ? where id = ? ");
            pst.setString(1, name);
            pst.setString(2, username);
            pst.setString(3, mobile);
            pst.setString(4, address);
            pst.setString(5, designation);
            pst.setString(6, question);
            pst.setString(7, answer);
            pst.setString(8, password);
            pst.setInt(9, id);
            pst.executeUpdate();
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Employee Record Updation.");

            alert.setHeaderText("Employee Record Update...");
            alert.setContentText("Updateddd!");

            alert.showAndWait();
            table();

            ename.setText("");
            eusername.setText("");
            ephone.setText("");
            eaddress.setText("");
            edesignation.setText("");
            //ecombobox.setAccessibleText("");
            eanswer.setText("");
            epassword.setText("");
            ename.requestFocus();
        }
        catch (SQLException ex)
        {
            Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void Connect()
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/planet","root","the1236@$gifted");
        } catch (ClassNotFoundException ex) {

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        ObservableList<String> questionBoxList = FXCollections.observableArrayList("What is your favorite color?", "In what city were you born?", "What is your pets name?", "Which high school did you attend?", "What is your nickname?");
        ecombobox.setItems(questionBoxList);
        Connect();
        table();


    }

    public void question(ActionEvent event) {

        String s= ecombobox.getSelectionModel().getSelectedItem().toString();
        question = s;
    }
}
