package com.example.mainlogin.Book;

public class ReadingBook extends boi{

    public ReadingBook(int id, String name, String author, String genre, String publisher, String price, String availability) {
        super(id, name, author, genre, publisher, price, availability);
    }



    String url = "newbook";
    public void processing() {
        super.processing(url);
    }
}
