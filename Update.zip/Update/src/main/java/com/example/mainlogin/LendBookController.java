package com.example.mainlogin;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LendBookController implements Initializable {

    public Button lendfx;
    public TextField memidtf;
    public TextField memnmtf;
    public TextField bknmtf;
    public TextField bkidtf;
    public TextField qtytf;
    public TextField cklabel;
    public TextField ck2tf;

    public Button issuefx;
    public Button ck2;
    //public TableView table;

    @FXML
    private TableView<Iss2> ldtabfx;

    @FXML
    private TableColumn<Iss2, String> ldidcolm;

    @FXML
    private TableColumn<Iss2, String> ldmemidcolm;

    @FXML
    private TableColumn<Iss2, String> ldmemnmcolm;

    @FXML
    private TableColumn<Iss2, String> ldbknmcolm;
    @FXML
    private TableColumn<Iss2, String> ldbkidcolm;



    Connection con;
    PreparedStatement pst;
    int myIndex;
    int id;

    public void Connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/planet", "root", "the1236@$gifted");
        } catch (ClassNotFoundException ex) {

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void tablelend() {
        Connect();
        ObservableList<Iss2> students = FXCollections.observableArrayList();
        try {
            pst = con.prepareStatement("select id,memberid,membername,bookname,bookid from lend");
            ResultSet rs = pst.executeQuery();
            {
                while (rs.next()) {
                    Iss2 st = new Iss2();

                    st.setId(rs.getString("id"));
                    st.setMemberid(rs.getString("memberid"));
                    st.setMembername(rs.getString("membername"));
                    st.setBookname(rs.getString("bookname"));
                    st.setBookid(rs.getString("bookid"));
                    //st.setTotal(rs.getString("total"));
                    students.add(st);


                    //students.add(new Employee(rs.getString("id"), rs.getString("name"), rs.getString("mobile"), rs.getString("address"), rs.getString("designation")));
                }
            }
            ldtabfx.setItems(students);
            ldidcolm.setCellValueFactory(f -> f.getValue().idProperty());
            ldmemidcolm.setCellValueFactory(f -> f.getValue().memberidProperty());
            ldmemnmcolm.setCellValueFactory(f -> f.getValue().membernameProperty());
            ldbknmcolm.setCellValueFactory(f -> f.getValue().booknameProperty());
            ldbkidcolm.setCellValueFactory(f -> f.getValue().bookidProperty());
            //qtytc.setCellValueFactory(f -> f.getValue().quantityProperty());
            //tottc.setCellValueFactory(f -> f.getValue().totalProperty());


        } catch (SQLException ex) {
            Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
        }

        ldtabfx.setRowFactory(tv -> {
            TableRow<Iss2> myRow = new TableRow<>();
            myRow.setOnMouseClicked(event ->
            {
                if (event.getClickCount() == 1 && (!myRow.isEmpty())) {
                    myIndex = ldtabfx.getSelectionModel().getSelectedIndex();
                    id = Integer.parseInt(String.valueOf(ldtabfx.getItems().get(myIndex).getId()));
                    memidtf.setText(ldtabfx.getItems().get(myIndex).getMemberid());
                    memnmtf.setText(ldtabfx.getItems().get(myIndex).getMembername());
                    bknmtf.setText(ldtabfx.getItems().get(myIndex).getBookname());
                    bkidtf.setText(ldtabfx.getItems().get(myIndex).getBookid());
                    //totlabel.setText(table.getItems().get(myIndex).getTotal());


                }
            });
            return myRow;
        });


    }




    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        Connect();
        tablelend();


    }

    void clear1() {
        memidtf.setText("");
        memnmtf.setText("");
        bknmtf.setText("");
        bkidtf.setText("");
        cklabel.setText("");
        ck2tf.setText("");

    }

    public void backlend(ActionEvent event) throws Exception{
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("IssueNew.fxml"));
        Stage window = (Stage) lendfx.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));
    }
    int flag2 = 0;

    public void ckbtn(ActionEvent event) throws Exception{

        String item = memidtf.getText();
        //String qty = qtytf.getText();
        //String price = tfprice.getText();
        String s ="";
        if(item != s){
            try {
                // pst = con.prepareStatement("select name,address,subject,marks from demo where id = ?");
                pst = con.prepareStatement("select name,phone,address,date from addmember where id = ?");
                //pst = con.prepareStatement("select address,subject,marks from demo where name = ?");
                pst.setString(1, item);
                // pst.setString(2, price);

                //pst.executeUpdate();
                ResultSet rs = pst.executeQuery();


                if(rs.next() == true){
                    String name = rs.getString(1);
                    String phone = rs.getString(2);
                    String address = rs.getString(3);
                    String date = rs.getString(4);
                    //String m2 = rs.getString(5);
                    //String marks3 = rs.getString(6);
                    //String marks4 = rs.getString(7);

                    memnmtf.setText(name);
                    //uptf.setText(m2);

                   // int inqty = Integer.parseInt(qtytf.getText());
                    //int avl = Integer.parseInt(marks3);
                    if(memnmtf.getText() != s)
                    {
                        cklabel.setText("Member found");
                        flag2 = 1;
                    }
                    else {
                        cklabel.setText("Member not found");
                    }
                    //System.out.println(name);
                    //System.out.println(address);
                    //System.out.println(subject);
                    //System.out.println(marks);
                }

                // table();

                //clear();

            } catch (SQLException ex) {
                Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
            }

        }



    }

    //public void total(ActionEvent event) {
    //}
    int flag1 = 0;

    public void issuebtn(ActionEvent event) throws Exception{
        String memberid = memidtf.getText();
        String membername = memnmtf.getText();
        String booknm = bknmtf.getText();
        String bookid = bkidtf.getText();
        //String total = totlabel.getText();
        if (flag1 == 1 && flag2 == 1) {

            String s = "";
            if (memberid != s && membername != s && booknm != s && bookid !=s) {

                try {
                    pst = con.prepareStatement("insert into lend(memberid,membername,bookname,bookid)values(?,?,?,?)");
                    pst.setString(1, memberid);
                    pst.setString(2, membername);
                    pst.setString(3, booknm);
                    pst.setString(4, bookid);
                    //pst.setString(5, total);


                    pst.executeUpdate();

                    tablelend();
                    clear1();
                    flag1 = 0;
                    flag2=0;
                } catch (SQLException ex) {
                    Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
            else{
                //trlabel1.setText("Please Enter Information");

            }
        }
    }

    public void ck2action(ActionEvent event) throws Exception{

        String item = bkidtf.getText();
        //String qty = qtytf.getText();
        //String price = tfprice.getText();
        String s ="";
        if(item != s ){
            try {
                // pst = con.prepareStatement("select name,address,subject,marks from demo where id = ?");
                pst = con.prepareStatement("select name,author,genre,publisher,price,availability,type from readtable where id = ?");
                //pst = con.prepareStatement("select address,subject,marks from demo where name = ?");
                pst.setString(1, item);
                // pst.setString(2, price);

                //pst.executeUpdate();
                ResultSet rs = pst.executeQuery();


                if(rs.next() == true){
                    String name = rs.getString(1);
                    String address = rs.getString(2);
                    String  subject = rs.getString(3);
                    String marks = rs.getString(4);
                    String m2 = rs.getString(5);
                    String marks3 = rs.getString(6);
                    String marks4 = rs.getString(7);

                    bknmtf.setText(name);
                    //uptf.setText(m2);

                    //int inqty = Integer.parseInt(qtytf.getText());
                    int avl = Integer.parseInt(marks3);
                    if(avl>0)
                    {
                        ck2tf.setText("Available");
                        flag1 = 1;
                    }
                    else {
                        ck2tf.setText("Not Available");
                    }
                    //System.out.println(name);
                    //System.out.println(address);
                    //System.out.println(subject);
                    //System.out.println(marks);
                }

                // table();

                //clear();

            } catch (SQLException ex) {
                Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
            }

        }



    }
}
