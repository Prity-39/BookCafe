package com.example.mainlogin;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class IssueNewController {


    public Button idsell;
    public Button idreturn;
    public Button idlend;
   // public Button Back;
    public Button back;

   /* public void backbtn(ActionEvent event) throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Dashboard.fxml"));
        Stage window = (Stage) Back.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));
    }*/

    public void sellbtn(ActionEvent event) throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("SellBook.fxml"));
        Stage window = (Stage) idsell.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));

    }

    public void returnbtn(ActionEvent event) throws Exception{

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("ReturnBook.fxml"));
        Stage window = (Stage) idreturn.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));
    }

    public void lendbtn(ActionEvent event) throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("LendBook.fxml"));
        Stage window = (Stage) idlend.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));
    }

    public void Backbtn(ActionEvent event) throws Exception{
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Dashboard.fxml"));
        Stage window = (Stage) back.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));
    }
}
