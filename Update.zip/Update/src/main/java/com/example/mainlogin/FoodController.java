package com.example.mainlogin;

import com.example.mainlogin.database.Employee;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FoodController implements Initializable {

    public Button savefood;
    //public Button cancelfood;
    public Label msgLabel;
    public Button updatefood;
    public TextField fxqty;
    public Button fxtotal;
    public TextField totalshow;
    public TextField tfname;

    @FXML
    private TableView<Food2> histable;
    @FXML
    private TableColumn<Food2, String> hisidcolm;
    @FXML
    private TableColumn<Food2, String> hisnamecolm;

    @FXML
    private TableColumn<Food2, String> hisitemcolm;

    @FXML
    private TableColumn<Food2, String> hispricecolm;
    @FXML
    private TableColumn<Food2, String> hisquantitycolm;
    @FXML
    private TableColumn<Food2, String> histotalcolm;
    //public TableColumn histotalcolm;
    //public Button savefood;

    /*@FXML
    public TableView menutable;
    public TableColumn idcolm;
    public TableColumn itemcolm;

    public TableColumn pricecolm;*/

    @FXML
    private TableView<Food> menutable;
    @FXML
    private TableColumn<Food, String> idcolm;
    @FXML
    private TableColumn<Food, String> itemcolm;

    @FXML
    private TableColumn<Food, String> pricecolm;

    public Button addfood;




    public TextField tfitem;
    public TextField tfprice;


    //public Button savefood1;
    //public TableView menutable1;
    //ublic TableColumn namecolm1;
    @FXML
    private Button btnReturn1;

    Connection con;
    PreparedStatement pst;
    int myIndex;
    int id;


    //click << button of Food page to enter Dashboard page
    public void handleBtn10() throws Exception{

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Dashboard.fxml"));
        Stage window = (Stage) btnReturn1.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));

    }

    void clear() {
        tfitem.setText("");
        tfprice.setText("");
        tfname.setText("");
        fxqty.setText("");
        fxtotal.setText("");
        totalshow.setText("");
    }

    public void table()
    {
        Connect();
        ObservableList<Food> students = FXCollections.observableArrayList();
        try
        {
            pst = con.prepareStatement("select id,item,price from menu");
            ResultSet rs = pst.executeQuery();
            {
                while (rs.next())
                {
                    Food st = new Food();

                    st.setId(rs.getString("id"));
                    st.setItem(rs.getString("item"));
                    st.setPrice(rs.getString("price"));
                    //st.setAddress(rs.getString("address"));
                    //st.setDesignation(rs.getString("designation"));
                    students.add(st);



                    //students.add(new Employee(rs.getString("id"), rs.getString("name"), rs.getString("mobile"), rs.getString("address"), rs.getString("designation")));
                }
            }
            menutable.setItems(students);
            idcolm.setCellValueFactory(f -> f.getValue().idProperty());
            itemcolm.setCellValueFactory(f -> f.getValue().itemProperty());
            pricecolm.setCellValueFactory(f -> f.getValue().priceProperty());
           //teaddress.setCellValueFactory(f -> f.getValue().addressProperty());
            //tedesignation.setCellValueFactory(f -> f.getValue().designationProperty());






        }

        catch (SQLException ex)
        {
            Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
        }

        menutable.setRowFactory( tv -> {
            TableRow<Food> myRow = new TableRow<>();
            myRow.setOnMouseClicked (event ->
            {
                if (event.getClickCount() == 1 && (!myRow.isEmpty()))
                {
                    myIndex =  menutable.getSelectionModel().getSelectedIndex();
                    id = Integer.parseInt(String.valueOf(menutable.getItems().get(myIndex).getId()));
                    tfitem.setText(menutable.getItems().get(myIndex).getItem());
                    tfprice.setText(menutable.getItems().get(myIndex).getPrice());
                    /*ephone.setText(table.getItems().get(myIndex).getMobile());
                    eaddress.setText(table.getItems().get(myIndex).getAddress());
                    edesignation.setText(table.getItems().get(myIndex).getDesignation());
                    //ecombobox.setAccessibleText(table.getItems().get(myIndex).getName());
                    eanswer.setText(table.getItems().get(myIndex).getAnswer());
                    epassword.setText(table.getItems().get(myIndex).getPassword());*/




                }
            });
            return myRow;
        });


    }


    public void historytable()
    {
        Connect();
        ObservableList<Food2> students = FXCollections.observableArrayList();
        try
        {
            pst = con.prepareStatement("select id,name,item,price,quantity,total from history");
            ResultSet rs = pst.executeQuery();
            {
                while (rs.next())
                {
                    Food2 st = new Food2();

                    st.setId(rs.getString("id"));
                    st.setName(rs.getString("name"));
                    st.setItem(rs.getString("item"));
                    st.setPrice(rs.getString("price"));
                    st.setQuantity(rs.getString("quantity"));
                    st.setTotal(rs.getString("total"));
                    students.add(st);



                    //students.add(new Employee(rs.getString("id"), rs.getString("name"), rs.getString("mobile"), rs.getString("address"), rs.getString("designation")));
                }
            }
            histable.setItems(students);
            hisidcolm.setCellValueFactory(f -> f.getValue().idProperty());
            hisnamecolm.setCellValueFactory(f -> f.getValue().nameProperty());
            hisitemcolm.setCellValueFactory(f -> f.getValue().itemProperty());
            hispricecolm.setCellValueFactory(f -> f.getValue().priceProperty());
            hisquantitycolm.setCellValueFactory(f -> f.getValue().quantityProperty());
            histotalcolm.setCellValueFactory(f -> f.getValue().totalProperty());






        }

        catch (SQLException ex)
        {
            Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
        }

        histable.setRowFactory( tv -> {
            TableRow<Food2> myRow = new TableRow<>();
            myRow.setOnMouseClicked (event ->
            {
                if (event.getClickCount() == 1 && (!myRow.isEmpty()))
                {
                    myIndex =  histable.getSelectionModel().getSelectedIndex();
                    id = Integer.parseInt(String.valueOf(histable.getItems().get(myIndex).getId()));
                    tfname.setText(histable.getItems().get(myIndex).getName());
                    tfitem.setText(histable.getItems().get(myIndex).getItem());
                    tfprice.setText(histable.getItems().get(myIndex).getPrice());
                    fxqty.setText(histable.getItems().get(myIndex).getQuantity());
                    totalshow.setText(histable.getItems().get(myIndex).getTotal());
                    //ecombobox.setAccessibleText(table.getItems().get(myIndex).getName());
                    //eanswer.setText(table.getItems().get(myIndex).getAnswer());
                    //epassword.setText(table.getItems().get(myIndex).getPassword());




                }
            });
            return myRow;
        });


    }

    public void foodadd(ActionEvent event) throws Exception {
        String item = tfitem.getText();
        String price = tfprice.getText();

        try {
            pst = con.prepareStatement("insert into menu(item,price)values(?,?)");
            pst.setString(1, item);
            pst.setString(2, price);

            pst.executeUpdate();

            table();

            clear();
        } catch (SQLException ex) {
            Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void foodupdate(ActionEvent event) throws Exception{

        myIndex = menutable.getSelectionModel().getSelectedIndex();
        id = Integer.parseInt(String.valueOf(menutable.getItems().get(myIndex).getId()));

        String item = tfitem.getText();
        String price = tfprice.getText();
        /*String mobile = ephone.getText();
        String  address = eaddress.getText();
        String  designation=edesignation.getText();
        //String question = ecombobox.getAccessibleText();
        String  answer = eanswer.getText();
        String password=epassword.getText();*/
        try
        {
            pst = con.prepareStatement("update menu set item = ?,price = ? where id = ? ");
            pst.setString(1, item);
            pst.setString(2, price);
            /*pst.setString(3, mobile);
            pst.setString(4, address);
            pst.setString(5, designation);
            pst.setString(6, question);
            pst.setString(7, answer);
            pst.setString(8, password);*/
            pst.setInt(3, id);
            pst.executeUpdate();
            /*Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Employee Record Updation.");

            alert.setHeaderText("Employee Record Update...");
            alert.setContentText("Updateddd!");

            alert.showAndWait();*/
            table();

            tfitem.setText("");
            tfprice.setText("");
            /*ephone.setText("");
            eaddress.setText("");
            edesignation.setText("");
            //ecombobox.setAccessibleText("");
            eanswer.setText("");
            epassword.setText("");*/
            tfitem.requestFocus();
        }
        catch (SQLException ex)
        {
            Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
        }


    }

    public void Connect()
    {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/planet","root","the1236@$gifted");
        } catch (ClassNotFoundException ex) {

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    int flag = 0;

    public void totalaction(ActionEvent event) {

        String qty = fxqty.getText();
        String price = tfprice.getText();
        String s = "";
        if(qty != s && price != s){
            int inqty = Integer.parseInt(qty);
            int unprice = Integer.parseInt(price);
            int total = inqty*unprice;
            String t = Integer.toString(total);
            totalshow.setText(t);
            flag=1;
        }

    }


    public void foodsave(ActionEvent event) {
        String qty = fxqty.getText();
        String price = tfprice.getText();
        String name = tfname.getText();
        String item = tfitem.getText();
        String total = totalshow.getText();
        //String price = tfprice.getText();

        if(flag == 1){
            String  s = "";
            if(qty != s && price != s && name != s && item != s && total != s){

                try {
                    pst = con.prepareStatement("insert into history(name,item,price,quantity,total)values(?,?,?,?,?)");
                    pst.setString(1, name);
                    pst.setString(2, item);
                    pst.setString(3, price);
                    pst.setString(4, qty);
                    pst.setString(5, total);


                    pst.executeUpdate();

                    historytable();

                    clear();
                    flag = 0;
                } catch (SQLException ex) {
                    Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
                }




            }
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Connect();
        table();
        historytable();
    }





/*
    public void fooddelete(ActionEvent event) {
    }

    public void foodupdate(ActionEvent event) {
    }

    public void foodsave(ActionEvent event) {
    }

    public void foodcancel(ActionEvent event) {
    }

    public void save(ActionEvent event) {
    }*/
}
