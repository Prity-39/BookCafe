package com.example.mainlogin;

import com.example.mainlogin.database.DatabaseConnection;
import com.example.mainlogin.database.Employee;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AddBookController implements Initializable {
    @FXML
    public Label msgLabel;

    @FXML
    public TextField book_author;
    @FXML
    public TextField book_name;
    @FXML
    public TextField book_genre;
    @FXML
    public TextField book_publisher;
    @FXML
    public TextField book_price;
    @FXML
    public TextField book_availability;
    @FXML
    public ComboBox addbookcombo;

    String type;
    String type1 = "Book for selling" ;
    String type2 = "Book for reading";

    @FXML
    public Button abcancel;
    //public TableView table;

    //public TextField available_buying;
    //public TextField available_reading;
    @FXML
    private Button btnReturn3;
    @FXML
    public Button book_save;

    Connection con;
    PreparedStatement pst;
    int myIndex;

    int id;



    //click << button of AddBook page to enter Dashboard page
    public void handleBtn12() throws Exception {

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Dashboard.fxml"));
        Stage window = (Stage) btnReturn3.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));

    }


    public void save(ActionEvent event) throws IOException {
        ResultSet rs;
        PreparedStatement ps;
        DatabaseConnection connect = new DatabaseConnection();
        try {

            Connection con = connect.getConnection();

            String name = book_name.getText().trim();
            String author = book_author.getText().trim();
            String genre = book_genre.getText().trim();
            String publisher = book_publisher.getText().trim();
            String price = book_price.getText().trim();
            //String type = addbookcombo.getAccessibleText();
            String availability = book_availability.getText().trim();

            if (name.isEmpty() || publisher.isEmpty() || genre.isEmpty() || author.isEmpty() || price.isEmpty()  || availability.isEmpty() || type.isEmpty()) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Library Error");
                alert.setHeaderText("Add Book Error!");
                alert.setContentText("Complete all the fields to insert a book to the system.");

                alert.showAndWait();
            } else {

                if(type == type1) {

                    String sql2 = "insert into newbook(name,author,genre,publisher,price,availability,type) value (?,?,?,?,?,?,?)";
                    ps = con.prepareStatement(sql2);
                } else
                {
                    type = type2;
                    String sql3 = "insert into readtable(name,author,genre,publisher,price,availability,type) value (?,?,?,?,?,?,?)";
                    ps = con.prepareStatement(sql3);

                }


                ps.setString(1, name);
                ps.setString(2, author);
                ps.setString(3, genre);
                ps.setString(4, publisher);
                ps.setString(5, price);

                ps.setString(6, availability);
                ps.setString(7,type);

                ps.execute();

                msgLabel.setText("Book added to the system");
                clear();

            }

        } catch (Exception e) {
            System.out.println("error" + e);
        }
    }

    public void cancel(ActionEvent event) throws Exception{

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Dashboard.fxml"));
        Stage window = (Stage) abcancel.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));
    }

    void clear(){
        book_name.setText("");
        book_author.setText("");
        book_genre.setText("");
        book_publisher.setText("");
        book_price.setText("");
        book_availability.setText("");
        addbookcombo.setAccessibleText("");

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ObservableList<String> type = FXCollections.observableArrayList("Book for selling", "Book for reading");
        addbookcombo.setItems(type);
        // TODO

    }

    public void combo(ActionEvent event) {
        String s= addbookcombo.getSelectionModel().getSelectedItem().toString();
        type = s;
    }
}










