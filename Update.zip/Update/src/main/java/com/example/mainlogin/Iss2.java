package com.example.mainlogin;


import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Iss2 extends IssueNewController{
    private final StringProperty id;
    private final StringProperty memberid;
    private final StringProperty membername;
    private final StringProperty bookid;
    private final StringProperty bookname;
    //private final StringProperty total;

    public Iss2() {
        id = new SimpleStringProperty(this, "id");
        memberid = new SimpleStringProperty(this, "memberid");
        membername = new SimpleStringProperty(this, "membername");
        bookname= new SimpleStringProperty(this, "bookname");
        bookid = new SimpleStringProperty(this, "bookid");
        //total = new SimpleStringProperty(this, "total");
    }

    public String getId() {
        return id.get();
    }

    public StringProperty idProperty() {
        return id;
    }

    public void setId(String id) {
        this.id.set(id);
    }

    public String getMemberid() {
        return memberid.get();
    }

    public StringProperty memberidProperty() {
        return memberid;
    }

    public void setMemberid(String memberid) {
        this.memberid.set(memberid);
    }

    public String getMembername() {
        return membername.get();
    }

    public StringProperty membernameProperty() {
        return membername;
    }

    public void setMembername(String membername) {
        this.membername.set(membername);
    }

    public String getBookid() {
        return bookid.get();
    }

    public StringProperty bookidProperty() {
        return bookid;
    }

    public void setBookid(String bookid) {
        this.bookid.set(bookid);
    }

    public String getBookname() {
        return bookname.get();
    }

    public StringProperty booknameProperty() {
        return bookname;
    }

    public void setBookname(String bookname) {
        this.bookname.set(bookname);
    }


}

