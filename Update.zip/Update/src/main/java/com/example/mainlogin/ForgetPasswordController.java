package com.example.mainlogin;

import com.example.mainlogin.database.DatabaseConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

public class ForgetPasswordController implements Initializable{
    @FXML
    public Label fptrlabel;
    @FXML
    public TextField fpid;
    @FXML
    public TextField fpusername;
    @FXML
    public TextField fpphoneno;
    @FXML
    public ComboBox fpcombobox;

    String question;

    @FXML
    public TextField fpanswer;
    @FXML
    public TextField nppassword;

    @FXML
    public Button fpverify;


    @FXML
    public Button btnReturnfp;

    //int flag = 0;

    // forget password page er verify button e click kore new password er page e enter korar code:::::

    public void verification() {

            if (fpid.getText().isBlank() == false && fpusername.getText().isBlank() == false && fpphoneno.getText().isBlank() == false  && fpanswer.getText().isBlank() == false) {
                //loginMessageLabel.setText("You try to login!");
                verifyPassword();
            } else {
                fptrlabel.setText("Please enter required information!");
                //validateLogin();
            }


        }




    public void fpback(ActionEvent event) throws Exception{
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Login.fxml"));
        Stage window = (Stage) btnReturnfp.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));
    }

    void verify()
    {

        fptrlabel.setText("Password is updated!");
    }

    public void clear(){

        fpid.setText("");
        fpusername.setText("");
        fpphoneno.setText("");
        fpcombobox.setAccessibleText("");
        nppassword.setText("");

        //String question;

        //@FXML
        fpanswer.setText("");

    }
    PreparedStatement pst;

    public void verifyPassword(){
        com.example.mainlogin.database.DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();
        String verifyPassword = "select count(1) from registation where id = '" + fpid.getText() +"'  and answer = '" + fpanswer.getText() +"'";
        try {
            Statement statement = connectDB.createStatement();
            ResultSet queryResult = statement.executeQuery(verifyPassword);
            while (queryResult.next()){
                if(queryResult.getInt(1) == 1){
                    //String sql = "Update registation SET password = "+ nppassword + "WHERE name =" + fpname +";";
                    //String sql2 = "UPDATE registation  SET  password = " + nppassword.getText() +  " WHERE id = ?";
                    /*String sql2 = "update registation set password = ? where id='" + fpid.getText() + "' ";
                    try {
                        queryResult = statement.executeQuery(sql2);
                    }catch (Exception e){
                        //e.printStackTrace();
                        System.out.println("Password is not updated");
                    }*/
                    //    Statement statement1 = connectDB.createStatement();
                      //  ResultSet queryResult1 = statement1.executeQuery(sql2);



                    pst = con.prepareStatement("update registation set password = ? where username = ? ");
                    //pst.setString(1, name);
                    //pst.setString(2, username);
                    //pst.setString(3, mobile);
                    //pst.setString(4, address);
                    //pst.setString(5, designation);
                    //pst.setString(6, question);
                   // pst.setString(7, answer);
                   // pst.setString(9, nppassword.getText());
                   // pst.setString(3, fpusername.getText());
                   //pst.setInt(9, fpid.getId());
                    //pst.executeUpdate();
                    verify();
                    clear();
                    System.out.println("Right");
                }
               else {

                   clear();
                    fptrlabel.setText("Wrong Information!");
                   // fptrlabel.setText("Password is updated!");

                }
            }

        } catch (Exception e){
            e.printStackTrace();
        }
    }
    Connection con;

    private void Connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/planet","root","the1236@$gifted");
        } catch (ClassNotFoundException ex) {

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        ObservableList<String> questionBoxList = FXCollections.observableArrayList("What is your favorite color?", "In what city were you born?", "What is your pets name?", "Which high school did you attend?", "What is your nickname?");
        fpcombobox.setItems(questionBoxList);
        Connect();
        //verification();

    }




    public void question(ActionEvent event) {

        String s= fpcombobox.getSelectionModel().getSelectedItem().toString();

        question = s;
    }



    /*boolean verify(){
        return false;

    }*/
}
