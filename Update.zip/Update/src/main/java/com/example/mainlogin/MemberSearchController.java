package com.example.mainlogin;



import com.jfoenix.controls.JFXButton;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MemberSearchController implements Initializable {
    public Button btnReturn5;
    //@FXML
    //private Button btnReturn5;
    @FXML
    private TableView<MemberSearchModel> table;
    @FXML
    private TableColumn<MemberSearchModel, Integer> id;
    @FXML
    private TableColumn<MemberSearchModel, String> name;
    @FXML
    private TableColumn<MemberSearchModel, String> phone;
    // @FXML
    //private TableColumn<ProductSearchModel, Integer> modelYearTableColumn;
    @FXML
    private TableColumn<MemberSearchModel, String> address;
    @FXML
    private TableColumn<MemberSearchModel, String> date;

    //@FXML
    //private TableColumn<MemberSearchModel, String> due;

    //@FXML
   // private TableColumn<MemberSearchModel, String> availabilityTableColumn;


    @FXML
    private TextField search;

    ObservableList<MemberSearchModel> memberSearchModelObservableList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle resource){
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();
        //String productViewQuery = "SELECT id, name, author, genre, publisher, price, availability FROM newbook";
        String productViewQuery = "SELECT * FROM addmember";
        //String productInsertQuery = "Insert INTO product";

        try{
            Statement statement = connectDB.createStatement();
            ResultSet queryOutput = statement.executeQuery(productViewQuery);

            while (queryOutput.next()){
                Integer queryId = queryOutput.getInt("id");
                String queryName = queryOutput.getString("name");
                String queryPhone = queryOutput.getString("phone");
                //Integer queryModelYear = queryOutput.getInt("ModelYear");
                String queryAddress = queryOutput.getString("address");
                String queryDate = queryOutput.getString("date");
                //String queryDue = queryOutput.getString("due");
                //String queryAvailability = queryOutput.getString("availability");
                memberSearchModelObservableList.add(new MemberSearchModel(queryId, queryName, queryPhone, queryAddress, queryDate));

                id.setCellValueFactory(new PropertyValueFactory<>("memberId"));
                name.setCellValueFactory(new PropertyValueFactory<>("name"));
                phone.setCellValueFactory(new PropertyValueFactory<>("phone"));
                //modelYearTableColumn.setCellValueFactory(new PropertyValueFactory<>("modelYear"));
                address.setCellValueFactory(new PropertyValueFactory<>("address"));
                date.setCellValueFactory(new PropertyValueFactory<>("date"));
                //due.setCellValueFactory(new PropertyValueFactory<>("due"));
                //availabilityTableColumn.setCellValueFactory(new PropertyValueFactory<>("availability"));

                table.setItems(memberSearchModelObservableList);
            }
            FilteredList<MemberSearchModel> filteredData = new FilteredList<>(memberSearchModelObservableList, b->true);
            search.textProperty().addListener((observable, oldValue, newValue)-> {
                filteredData.setPredicate(memberSearchModel -> {
                    if(newValue.isEmpty() || newValue.isBlank() || newValue == null){
                        return true;
                    }
                    String searchKeyword = newValue.toLowerCase();
                    //--------------------------------------------------------------------------------------
                    if(memberSearchModel.getMemberId().toString().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(memberSearchModel.getMemberId().toString().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------
                    //--------------------------------------------------------------------------------------
                    else if(memberSearchModel.getName().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(memberSearchModel.getName().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------
                    //--------------------------------------------------------------------------------------
                    else if(memberSearchModel.getPhone().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(memberSearchModel.getPhone().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------
                    //--------------------------------------------------------------------------------------
                    else if(memberSearchModel.getName().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(memberSearchModel.getName().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------

                    else if(memberSearchModel.getAddress().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(memberSearchModel.getAddress().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    /*else if(memberSearchModel.getModelYear().toString().indexOf(searchKeyword) > -1){
                        return true;
                    }*/
                    //--------------------------------------------------------------------------------------
                    else if(memberSearchModel.getDate().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(memberSearchModel.getDate().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------

                    //--------------------------------------------------------------------------------------
                    /*else if(memberSearchModel.getDue().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(memberSearchModel.getDue().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }*/
                    //------------------------------------------------------------------------------------------


                    //--------------------------------------------------------------------------------------
                    /*else if(memberSearchModel.getAvailability().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(memberSearchModel.getAvailability().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }*/
                    //------------------------------------------------------------------------------------------


                    else {
                        return false;
                    }
                });
            });

            SortedList<MemberSearchModel> sortedData = new SortedList<>(filteredData);
            sortedData.comparatorProperty().bind(table.comparatorProperty());
            table.setItems(sortedData);

        } catch (SQLException e){
            Logger.getLogger(ProductSearchController.class.getName()).log(Level.SEVERE, null, e);
            e.printStackTrace();
        }

    }

    public void handleButton(ActionEvent event) {
    }

    public void handleBtn4() throws Exception{

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Dashboard.fxml"));
        Stage window = (Stage) btnReturn5.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));

    }
}


