package com.example.mainlogin;



//import com.example.mainlogin.Book.UsedBook;
import com.example.mainlogin.Book.*;
import com.jfoenix.controls.JFXButton;
import javafx.beans.Observable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ProductSearchController implements Initializable {
    public JFXButton btnReturn4;
    public Pane pn_ub;
    public Pane pn_rb;
    public Pane pn_nb;
    public JFXButton nb;
    public JFXButton ub;
    public JFXButton rb;



    @FXML
    private TableView<ProductSearchModel> productTableView;
    @FXML
    private TableColumn<ProductSearchModel, Integer> productIDTableColumn;
    @FXML
    private TableColumn<ProductSearchModel, String> brandTableColumn;
    @FXML
    private TableColumn<ProductSearchModel, String> modelNumberTableColumn;

    @FXML
    private TableColumn<ProductSearchModel, String> productNameTableColumn;
    @FXML
    private TableColumn<ProductSearchModel, String> descriptionTableColumn;

    @FXML
    private TableColumn<ProductSearchModel, String> priceTableColumn;



    @FXML
    private TableColumn<ProductSearchModel, String> availabilityTableColumn;


    @FXML
    private TextField keywordTextField;

    //startttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt

    @FXML
    private TableView<ProductSearchModel> usedTable;
    @FXML
    private TableColumn<ProductSearchModel, Integer> usedId;
    @FXML
    private TableColumn<ProductSearchModel, String> usedName;
    @FXML
    private TableColumn<ProductSearchModel, String> usedAuthor;
    @FXML
    private TableColumn<ProductSearchModel, String> usedGenre;

    @FXML
    private TableColumn<ProductSearchModel, String> usedPublisher;
    @FXML
    private TableColumn<ProductSearchModel, String> usedPrice;

    @FXML
    private TableColumn<ProductSearchModel, String> usedAvailability;



    @FXML
    private TextField usedSearch;

    @FXML
    private TableView<ProductSearchModel> readTable;
    @FXML
    private TableColumn<ProductSearchModel, Integer> readId;
    @FXML
    private TableColumn<ProductSearchModel, String> readName;
    @FXML
    private TableColumn<ProductSearchModel, String> readAuthor;
     @FXML
    private TableColumn<ProductSearchModel, Integer> readGenre;
    @FXML
    private TableColumn<ProductSearchModel, String> readPublisher;
    @FXML
    private TableColumn<ProductSearchModel, String> readPrice;

    @FXML
    private TableColumn<ProductSearchModel, String> readAvailability;




    @FXML
    private TextField readSearch;



    //enddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd


    ObservableList<ProductSearchModel> productSearchModelObservableList = FXCollections.observableArrayList();
    //ObservableList<ProductSearchModel> usedBookObservableList = FXCollections.observableArrayList();
    ObservableList<ProductSearchModel> readBookObservableList = FXCollections.observableArrayList();

    //starttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttt

    public void tableShow(String table){

        DatabaseConnection connectNow = new DatabaseConnection();

        Connection connectDB = connectNow.getConnection();

        String productViewQuery = "SELECT * FROM " + table;


        try{
            Statement statement = connectDB.createStatement();
            ResultSet queryOutput = statement.executeQuery(productViewQuery);

            while (queryOutput.next()){
                Integer queryProductID = queryOutput.getInt("id");
                String queryBrand = queryOutput.getString("name");
                String queryModelNumber = queryOutput.getString("author");
                String queryProductName = queryOutput.getString("genre");
                String queryDescription = queryOutput.getString("publisher");
                String queryPrice = queryOutput.getString("price");
                String queryAvailability = queryOutput.getString("availability");
                productSearchModelObservableList.add(new ProductSearchModel(queryProductID, queryBrand, queryModelNumber, queryProductName, queryDescription, queryPrice, queryAvailability));

                productIDTableColumn.setCellValueFactory(new PropertyValueFactory<>("productID"));
                brandTableColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
                modelNumberTableColumn.setCellValueFactory(new PropertyValueFactory<>("author"));
                //modelYearTableColumn.setCellValueFactory(new PropertyValueFactory<>("modelYear"));
                productNameTableColumn.setCellValueFactory(new PropertyValueFactory<>("genre"));
                descriptionTableColumn.setCellValueFactory(new PropertyValueFactory<>("publisher"));
                priceTableColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
                availabilityTableColumn.setCellValueFactory(new PropertyValueFactory<>("availability"));

                productTableView.setItems(productSearchModelObservableList);
            }
            FilteredList<ProductSearchModel> filteredData = new FilteredList<>(productSearchModelObservableList, b->true);
            keywordTextField.textProperty().addListener((observable, oldValue, newValue)-> {
                filteredData.setPredicate(productSearchModel -> {
                    if(newValue.isEmpty() || newValue.isBlank() || newValue == null){
                        return true;
                    }
                    String searchKeyword = newValue.toLowerCase();
                    //--------------------------------------------------------------------------------------
                    if(productSearchModel.getProductID().toString().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getProductID().toString().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------
                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getName().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getName().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------
                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getAuthor().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getAuthor().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------
                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getName().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getName().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------

                    else if(productSearchModel.getGenre().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getGenre().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }

                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getPublisher().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getPublisher().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------

                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getPrice().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getPrice().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------


                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getAvailability().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getAvailability().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------


                    else {
                        return false;
                    }
                });
            });

            SortedList<ProductSearchModel> sortedData = new SortedList<>(filteredData);
            sortedData.comparatorProperty().bind(productTableView.comparatorProperty());
            productTableView.setItems(sortedData);

        } catch (SQLException e){
            Logger.getLogger(ProductSearchController.class.getName()).log(Level.SEVERE, null, e);
            e.printStackTrace();
        }

    }

    /*public void tableShow2(String table){
        DatabaseConnection connectNow = new DatabaseConnection();

        Connection connectDB = connectNow.getConnection();

        String productViewQuery = "SELECT id, name, author, genre, publisher, price, availability FROM " + table;


        try{
            Statement statement = connectDB.createStatement();
            ResultSet queryOutput = statement.executeQuery(productViewQuery);

            while (queryOutput.next()){
                Integer queryProductID = queryOutput.getInt("id");
                String queryBrand = queryOutput.getString("name");
                String queryModelNumber = queryOutput.getString("author");
                String queryProductName = queryOutput.getString("genre");
                String queryDescription = queryOutput.getString("publisher");
                String queryPrice = queryOutput.getString("price");
                String queryAvailability = queryOutput.getString("availability");
                usedBookObservableList.add(new ProductSearchModel(queryProductID, queryBrand, queryModelNumber, queryProductName, queryDescription, queryPrice, queryAvailability));

                usedId.setCellValueFactory(new PropertyValueFactory<>("productID"));
                usedName.setCellValueFactory(new PropertyValueFactory<>("name"));
                usedAuthor.setCellValueFactory(new PropertyValueFactory<>("author"));
                usedGenre.setCellValueFactory(new PropertyValueFactory<>("genre"));
                usedPublisher.setCellValueFactory(new PropertyValueFactory<>("publisher"));
                usedPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
                usedAvailability.setCellValueFactory(new PropertyValueFactory<>("availability"));

                usedTable.setItems(usedBookObservableList);
            }
            FilteredList<ProductSearchModel> filteredData = new FilteredList<>(usedBookObservableList, b->true);
            usedSearch.textProperty().addListener((observable, oldValue, newValue)-> {
                filteredData.setPredicate(productSearchModel -> {
                    if(newValue.isEmpty() || newValue.isBlank() || newValue == null){
                        return true;
                    }
                    String searchKeyword = newValue.toLowerCase();
                    //--------------------------------------------------------------------------------------
                    if(productSearchModel.getProductID().toString().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getProductID().toString().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------
                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getName().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getName().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------
                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getAuthor().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getAuthor().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------
                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getName().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getName().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------

                    else if(productSearchModel.getGenre().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getGenre().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getPublisher().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getPublisher().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------

                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getPrice().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getPrice().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------


                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getAvailability().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getAvailability().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------


                    else {
                        return false;
                    }
                });
            });

            SortedList<ProductSearchModel> sortedData = new SortedList<>(filteredData);
            sortedData.comparatorProperty().bind(usedTable.comparatorProperty());
            usedTable.setItems(sortedData);

        } catch (SQLException e){
            Logger.getLogger(ProductSearchController.class.getName()).log(Level.SEVERE, null, e);
            e.printStackTrace();
        }
    }*/

    public void tableShow3(String table){
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();
        String productViewQuery = "SELECT * FROM " + table;

        try{
            Statement statement = connectDB.createStatement();
            ResultSet queryOutput = statement.executeQuery(productViewQuery);

            while (queryOutput.next()){
                Integer queryProductID = queryOutput.getInt("id");
                String queryBrand = queryOutput.getString("name");
                String queryModelNumber = queryOutput.getString("author");
                String queryProductName = queryOutput.getString("genre");
                String queryDescription = queryOutput.getString("publisher");
                String queryPrice = queryOutput.getString("price");
                String queryAvailability = queryOutput.getString("availability");
                readBookObservableList.add(new ProductSearchModel(queryProductID, queryBrand, queryModelNumber, queryProductName, queryDescription, queryPrice, queryAvailability));

                readId.setCellValueFactory(new PropertyValueFactory<>("productID"));
                readName.setCellValueFactory(new PropertyValueFactory<>("name"));
                readAuthor.setCellValueFactory(new PropertyValueFactory<>("author"));
                readGenre.setCellValueFactory(new PropertyValueFactory<>("genre"));
                readPublisher.setCellValueFactory(new PropertyValueFactory<>("publisher"));
                readPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
                readAvailability.setCellValueFactory(new PropertyValueFactory<>("availability"));

                readTable.setItems(readBookObservableList);
            }
            FilteredList<ProductSearchModel> filteredData = new FilteredList<>(readBookObservableList, b->true);
            readSearch.textProperty().addListener((observable, oldValue, newValue)-> {
                filteredData.setPredicate(productSearchModel -> {
                    if(newValue.isEmpty() || newValue.isBlank() || newValue == null){
                        return true;
                    }
                    String searchKeyword = newValue.toLowerCase();
                    //--------------------------------------------------------------------------------------
                    if(productSearchModel.getProductID().toString().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getProductID().toString().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------
                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getName().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getName().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------
                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getAuthor().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getAuthor().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------
                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getName().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getName().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------

                    else if(productSearchModel.getGenre().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getGenre().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getPublisher().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getPublisher().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------

                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getPrice().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getPrice().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------


                    //--------------------------------------------------------------------------------------
                    else if(productSearchModel.getAvailability().toLowerCase().indexOf(searchKeyword) > -1){
                        return true;

                    }
                    else if(productSearchModel.getAvailability().toLowerCase().indexOf(searchKeyword) < -1){
                        return true;

                    }
                    //------------------------------------------------------------------------------------------


                    else {
                        return false;
                    }
                });
            });

            SortedList<ProductSearchModel> sortedData = new SortedList<>(filteredData);
            sortedData.comparatorProperty().bind(readTable.comparatorProperty());
            readTable.setItems(sortedData);

        } catch (SQLException e){
            Logger.getLogger(ProductSearchController.class.getName()).log(Level.SEVERE, null, e);
            e.printStackTrace();
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////


    //enddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd

    @Override
    public void initialize(URL url, ResourceBundle resource){
        String str = "newbook";
        //String str2 = "usedtable";
        String str3 = "readtable";
        tableShow(str);
        //tableShow2(str2);
        tableShow3(str3);

    }





    public void handleButton(ActionEvent event) {
        if(event.getSource() == ub){
            pn_ub.toFront();
        }
        else if(event.getSource() == nb){
            pn_nb.toFront();
        }
        else if(event.getSource() == rb){
            pn_rb.toFront();
        }
    }

    public void handleBtn13(ActionEvent event) throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Dashboard.fxml"));
        Stage window = (Stage) btnReturn4.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));
    }
}


