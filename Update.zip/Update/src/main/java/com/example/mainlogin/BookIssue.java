package com.example.mainlogin;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


public class BookIssue {
    private final StringProperty id;
    private final StringProperty name;
    private final StringProperty phone;
    private final StringProperty book;
    private final StringProperty publisher;
    private final StringProperty member;
    private final StringProperty price;

    public BookIssue() {
        id = new SimpleStringProperty(this, "id");
        name = new SimpleStringProperty(this, "name");
        phone = new SimpleStringProperty(this, "phone");
        book = new SimpleStringProperty(this, "book");
        publisher = new SimpleStringProperty(this, "publisher");
        member = new SimpleStringProperty(this, "member");
        price = new SimpleStringProperty(this, "price");
    }

    public String getId() {
        return id.get();
    }

    public StringProperty idProperty() {
        return id;
    }

    public void setId(String id) {
        this.id.set(id);
    }

    public String getName() {
        return name.get();
    }

    public StringProperty nameProperty() {
        return name;
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public String getPhone() {
        return phone.get();
    }

    public StringProperty phoneProperty() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone.set(phone);
    }

    public String getBook() {
        return book.get();
    }

    public StringProperty bookProperty() {
        return book;
    }

    public void setBook(String book) {
        this.book.set(book);
    }

    public String getPublisher() {
        return publisher.get();
    }

    public StringProperty publisherProperty() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher.set(publisher);
    }

    public String getMember() {
        return member.get();
    }

    public StringProperty memberProperty() {
        return member;
    }

    public void setMember(String member) {
        this.member.set(member);
    }

    public String getPrice() {
        return price.get();
    }

    public StringProperty priceProperty() {
        return price;
    }

    public void setPrice(String price) {
        this.price.set(price);
    }
}




