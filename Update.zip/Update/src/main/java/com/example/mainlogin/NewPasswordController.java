package com.example.mainlogin;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class NewPasswordController {
    @FXML
    public Button btnReturnnp;
    @FXML
    public TextField nppassword;
    @FXML
    public Button npupdate;
    @FXML
    public TextField npname;

    public void databaseUpdate(){

            //myIndex = table.getSelectionModel().getSelectedIndex();
            //id = Integer.parseInt(String.valueOf(table.getItems().get(myIndex).getId()));

            /*String name = npname.getText();
            String username = eusername.getText();
            String mobile = ephone.getText();
            String  address = eaddress.getText();
            String  designation=edesignation.getText();
            //String question = ecombobox.getAccessibleText();
            String  answer = eanswer.getText();
            String password=epassword.getText();
            try
            {
                pst = con.prepareStatement("update registation set name = ?,username = ?,mobile = ? ,address = ?,designation = ?,question = ?,answer = ?,password = ? where id = ? ");
                pst.setString(1, name);
                pst.setString(2, username);
                pst.setString(3, mobile);
                pst.setString(4, address);
                pst.setString(5, designation);
                pst.setString(6, question);
                pst.setString(7, answer);
                pst.setString(8, password);
                pst.setInt(9, id);
                pst.executeUpdate();
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Employee Record Updation.");

                alert.setHeaderText("Employee Record Update...");
                alert.setContentText("Updateddd!");

                alert.showAndWait();
                table();

                ename.setText("");
                eusername.setText("");
                ephone.setText("");
                eaddress.setText("");
                edesignation.setText("");
                //ecombobox.setAccessibleText("");
                eanswer.setText("");
                epassword.setText("");
                ename.requestFocus();
            }
            catch (SQLException ex)
            {
                Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
            }

        }*/


    }


    public void npback(ActionEvent event) throws Exception{
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Login.fxml"));
        Stage window = (Stage) btnReturnnp.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));
    }

    public void update(ActionEvent event) throws Exception{

        databaseUpdate();

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Login.fxml"));
        Stage window = (Stage) npupdate.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));


    }
}
