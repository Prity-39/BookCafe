package com.example.mainlogin;

import com.example.mainlogin.database.DatabaseConnection;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

public class AddMember implements Initializable {

    @FXML
    public TextField member_name;
    @FXML
    public TextField phn_no;
    @FXML
    public TextField member_address;
    @FXML
    public TextField membership_date;

    public Button btnReturn3;
    //public TextField member_name;
    //public TextField phn_no;
   // public TextField address;
    @FXML
    public Label saved;
    @FXML
    public Button save_button;
    @FXML
    public Button cancel_button;
    @FXML
    private Button btnReturn2;

    Connection con;
    PreparedStatement pst;
    int myIndex;
    int id;


    //click << button of AddMember page to enter Dashboard page
    public void handleBtn11() throws Exception{

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Dashboard.fxml"));
        Stage window = (Stage) btnReturn2.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));

    }

    public void save(ActionEvent event) throws IOException {
        ResultSet rs;
        PreparedStatement ps;
        DatabaseConnection connect = new DatabaseConnection();
        try {

            Connection con = connect.getConnection();

            String name = member_name.getText().trim();
            String phone = phn_no.getText().trim();
            String address = member_address.getText().trim();
            String date = membership_date.getText().trim();
           // String price = book_price.getText().trim();
            //String avaiability = book_availability.getText().trim();

            if (name.isEmpty() || date.isEmpty() ||address.isEmpty() || phone.isEmpty()) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Library Error");
                alert.setHeaderText("Add Member Error!");
                alert.setContentText("Complete all the fields to insert a member to the system.");

                alert.showAndWait();
            } else {

                String sql2 = "insert into addmember(name,phone,address,date) value (?,?,?,?)";
                ps = con.prepareStatement(sql2);

                ps.setString(1, member_name.getText().trim());
                ps.setString(2, phn_no.getText().trim());
                ps.setString(3, member_address.getText().trim());
                ps.setString(4, membership_date.getText().trim());
                //ps.setString(5, book_price.getText().trim());
                //ps.setString(6, book_availability.getText().trim());

                ps.execute();

                saved.setText("Member added to the system");
                clear();

            }

        } catch (Exception e) {
            System.out.println("error" + e);
        }

    }

    public void cancel(ActionEvent event) throws Exception{
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Dashboard.fxml"));
        Stage window = (Stage) cancel_button.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));
    }

    void clear(){
        member_name.setText("");
        phn_no.setText("");
        member_address.setText("");
        membership_date.setText("");

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}
