package com.example.mainlogin;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;


public class BookIssue2 {
    private final StringProperty id;
    private final StringProperty customername;
    private final StringProperty bookname;
    private final StringProperty unitprice;
    private final StringProperty quantity;
    private final StringProperty total;
    //private final StringProperty member;
    //private final StringProperty price;

    public BookIssue2() {
        id = new SimpleStringProperty(this, "id");
        customername = new SimpleStringProperty(this, "customername");
        bookname = new SimpleStringProperty(this, "bookname");
        unitprice = new SimpleStringProperty(this, "unitprice");
        quantity = new SimpleStringProperty(this, "quantity");
        total = new SimpleStringProperty(this, "total");
        //member = new SimpleStringProperty(this, "member");
        //price = new SimpleStringProperty(this, "price");
    }

    public String getId() {
        return id.get();
    }

    public StringProperty idProperty() {
        return id;
    }

    public void setId(String id) {
        this.id.set(id);
    }

    public String getCustomername() {
        return customername.get();
    }

    public StringProperty customernameProperty() {
        return customername;
    }

    public void setCustomername(String customername) {
        this.customername.set(customername);
    }

    public String getBookname() {
        return bookname.get();
    }

    public StringProperty booknameProperty() {
        return bookname;
    }

    public void setBookname(String bookname) {
        this.bookname.set(bookname);
    }

    public String getUnitprice() {
        return unitprice.get();
    }

    public StringProperty unitpriceProperty() {
        return unitprice;
    }

    public void setUnitprice(String unitprice) {
        this.unitprice.set(unitprice);
    }

    public String getQuantity() {
        return quantity.get();
    }

    public StringProperty quantityProperty() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity.set(quantity);
    }

    public String getTotal() {
        return total.get();
    }

    public StringProperty totalProperty() {
        return total;
    }

    public void setTotal(String total) {
        this.total.set(total);
    }
}
