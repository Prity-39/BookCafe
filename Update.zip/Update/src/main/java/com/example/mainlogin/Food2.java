package com.example.mainlogin;


import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Food2 extends Food{
    private final StringProperty id;
    private final StringProperty name;
    private final StringProperty item;
    private final StringProperty price;
    private final StringProperty quantity;
    private final StringProperty total;

    public Food2() {
        id = new SimpleStringProperty(this, "id");
        name = new SimpleStringProperty(this, "name");
        item = new SimpleStringProperty(this, "item");
        price = new SimpleStringProperty(this, "price");
        quantity = new SimpleStringProperty(this, "quantity");
        total = new SimpleStringProperty(this, "total");
    }

    public String getId() {
        return id.get();
    }

    public StringProperty idProperty() {
        return id;
    }

    public void setId(String id) {
        this.id.set(id);
    }

    public String getName() {
        return name.get();
    }

    public StringProperty nameProperty() {
        return name;
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public String getItem() {
        return item.get();
    }

    public StringProperty itemProperty() {
        return item;
    }

    public void setItem(String item) {
        this.item.set(item);
    }

    public String getPrice() {
        return price.get();
    }

    public StringProperty priceProperty() {
        return price;
    }

    public void setPrice(String price) {
        this.price.set(price);
    }

    public String getQuantity() {
        return quantity.get();
    }

    public StringProperty quantityProperty() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity.set(quantity);
    }

    public String getTotal() {
        return total.get();
    }

    public StringProperty totalProperty() {
        return total;
    }

    public void setTotal(String total) {
        this.total.set(total);
    }
}
