package com.example.mainlogin;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Food {
    private final StringProperty id;
    private final StringProperty item;
    private final StringProperty price;

    public Food() {
        id = new SimpleStringProperty(this, "id");
        item = new SimpleStringProperty(this, "item");
        price = new SimpleStringProperty(this, "price");
    }

    public String getId() {
        return id.get();
    }

    public StringProperty idProperty() {
        return id;
    }

    public void setId(String id) {
        this.id.set(id);
    }

    public String getItem() {
        return item.get();
    }

    public StringProperty itemProperty() {
        return item;
    }

    public void setItem(String item) {
        this.item.set(item);
    }

    public String getPrice() {
        return price.get();
    }

    public StringProperty priceProperty() {
        return price;
    }

    public void setPrice(String price) {
        this.price.set(price);
    }
}
