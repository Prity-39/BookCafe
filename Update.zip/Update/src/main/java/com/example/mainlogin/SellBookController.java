package com.example.mainlogin;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SellBookController  implements Initializable {
    public TextField cntf;
    public TextField bntf;
    public TextField uptf;
    public TextField qtytf;
    public TextField totlabel;
    public Button totfx;
    public Button savefx;
    public Button ck;
    public TextField bidtf;
    public TextField cklabel;
    public Button sellfx;
    public Label trlabel;

    @FXML
    private TableView<Iss> table;

    @FXML
    private TableColumn<Iss, String> idtc;

    @FXML
    private TableColumn<Iss, String> cntc;

    @FXML
    private TableColumn<Iss, String> bntc;

    @FXML
    private TableColumn<Iss, String> uptc;

    @FXML
    private TableColumn<Iss, String> qtytc;

    @FXML
    private TableColumn<Iss, String> tottc;

    Connection con;
    PreparedStatement pst;
    int myIndex;
    int id;

    public void Connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/planet", "root", "the1236@$gifted");
        } catch (ClassNotFoundException ex) {

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void tablesell() {
        Connect();
        ObservableList<Iss> students = FXCollections.observableArrayList();
        try {
            pst = con.prepareStatement("select id,customername,bookname,unitprice,quantity,total from sellbook3");
            ResultSet rs = pst.executeQuery();
            {
                while (rs.next()) {
                    Iss st = new Iss();

                    st.setId(rs.getString("id"));
                    st.setCustomername(rs.getString("customername"));
                    st.setBookname(rs.getString("bookname"));
                    st.setUnitprice(rs.getString("unitprice"));
                    st.setQuantity(rs.getString("quantity"));
                    st.setTotal(rs.getString("total"));
                    students.add(st);


                    //students.add(new Employee(rs.getString("id"), rs.getString("name"), rs.getString("mobile"), rs.getString("address"), rs.getString("designation")));
                }
            }
            table.setItems(students);
            idtc.setCellValueFactory(f -> f.getValue().idProperty());
            cntc.setCellValueFactory(f -> f.getValue().customernameProperty());
            bntc.setCellValueFactory(f -> f.getValue().booknameProperty());
            uptc.setCellValueFactory(f -> f.getValue().unitpriceProperty());
            qtytc.setCellValueFactory(f -> f.getValue().quantityProperty());
            tottc.setCellValueFactory(f -> f.getValue().totalProperty());


        } catch (SQLException ex) {
            Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
        }

        table.setRowFactory(tv -> {
            TableRow<Iss> myRow = new TableRow<>();
            myRow.setOnMouseClicked(event ->
            {
                if (event.getClickCount() == 1 && (!myRow.isEmpty())) {
                    myIndex = table.getSelectionModel().getSelectedIndex();
                    id = Integer.parseInt(String.valueOf(table.getItems().get(myIndex).getId()));
                    cntf.setText(table.getItems().get(myIndex).getCustomername());
                    bntf.setText(table.getItems().get(myIndex).getBookname());
                    uptf.setText(table.getItems().get(myIndex).getUnitprice());
                    qtytf.setText(table.getItems().get(myIndex).getQuantity());
                    totlabel.setText(table.getItems().get(myIndex).getTotal());


                }
            });
            return myRow;
        });


    }


    void clear() {
        cntf.setText("");
        bidtf.setText("");
        bntf.setText("");
        uptf.setText("");
        qtytf.setText("");
        totlabel.setText("");
        cklabel.setText("");
        //totalshow.setText("");
    }

    int flag = 0;
    public void total(ActionEvent event) throws Exception{
        String unitprice = uptf.getText();
        String quantity = qtytf.getText();
        //String qua = qtytf.getText();
        String s = "";
        if (unitprice != s && quantity != s) {
            int inunitprice = Integer.parseInt(unitprice);
            int inquantity = Integer.parseInt(quantity);
            int total = inunitprice * inquantity;
            String t = Integer.toString(total);
            totlabel.setText(t);
            flag = 1;
        }
    }

    public void savebtn(ActionEvent event) throws Exception{
        String customername = cntf.getText();
        String bookname = bntf.getText();
        String unitprice = uptf.getText();
        String quantity = qtytf.getText();
        String total = totlabel.getText();
        if (flag == 1 && flag2 == 1) {

            String s = "";
            if (customername != s && bookname != s && unitprice != s && quantity != s && total != s) {

                try {
                    pst = con.prepareStatement("insert into sellbook3(customername,bookname,unitprice,quantity,total)values(?,?,?,?,?)");
                    pst.setString(1, customername);
                    pst.setString(2, bookname);
                    pst.setString(3, unitprice);
                    pst.setString(4, quantity);
                    pst.setString(5, total);


                    pst.executeUpdate();

                    tablesell();
                    clear();
                    flag = 0;
                    flag2 = 0;
                } catch (SQLException ex) {
                    Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
                }

            }
            else{
                trlabel.setText("Please Enter Information");

            }
        }
    }


    int flag2 = 0;
    public void ckbtn(ActionEvent event) throws Exception{

        String item = bidtf.getText();
        String qty = qtytf.getText();
        //String price = tfprice.getText();
        String s ="";
        if(item != s && qty != s){
            try {
                // pst = con.prepareStatement("select name,address,subject,marks from demo where id = ?");
                pst = con.prepareStatement("select name,author,genre,publisher,price,availability,type from newbook where id = ?");
                //pst = con.prepareStatement("select address,subject,marks from demo where name = ?");
                pst.setString(1, item);
                // pst.setString(2, price);

                //pst.executeUpdate();
                ResultSet rs = pst.executeQuery();


                if(rs.next() == true){
                    String name = rs.getString(1);
                    String address = rs.getString(2);
                    String  subject = rs.getString(3);
                    String marks = rs.getString(4);
                    String m2 = rs.getString(5);
                    String marks3 = rs.getString(6);
                    String marks4 = rs.getString(7);

                    bntf.setText(name);
                    uptf.setText(m2);

                    int inqty = Integer.parseInt(qtytf.getText());
                    int avl = Integer.parseInt(marks3);
                    if(inqty < avl)
                    {
                        cklabel.setText("Available");
                        flag2 = 1;
                    }
                    else {
                        cklabel.setText("Not Available");
                    }
                    //System.out.println(name);
                    //System.out.println(address);
                    //System.out.println(subject);
                    //System.out.println(marks);
                }

                // table();

                //clear();

            } catch (SQLException ex) {
                Logger.getLogger(RegistrationController.class.getName()).log(Level.SEVERE, null, ex);
            }

        }



    }



    public void backsell(ActionEvent event) throws Exception{
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("IssueNew.fxml"));
        Stage window = (Stage) sellfx.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 1000, 700));
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Connect();
        tablesell();

    }
}
